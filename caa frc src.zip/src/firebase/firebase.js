// <!-- The core Firebase JS SDK is always required and must be listed first -->
// <script src="https://www.gstatic.com/firebasejs/8.3.0/firebase-app.js"></script>

// <!-- TODO: Add SDKs for Firebase products that you want to use
//      https://firebase.google.com/docs/web/setup#available-libraries -->

// <script>
//   // Your web app's Firebase configuration
//   var firebaseConfig = {
//     apiKey: "AIzaSyDw5INp-psE4rSVz942RvfDVLPJ0DFHzNs",
//     authDomain: "besafe-8e13b.firebaseapp.com",
//     projectId: "besafe-8e13b",
//     storageBucket: "besafe-8e13b.appspot.com",
//     messagingSenderId: "318990397213",
//     appId: "1:318990397213:web:22597c72ad8cedd4253bf4"
//   };
//   // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);
// </script>


// database/firebaseDb.js

import * as firebase from 'firebase';


var firebaseConfig = {
        apiKey: "AIzaSyBZQ1cocknvA_lMoMPOB5PkSiaA1Ehp4KQ",
        authDomain: "covidactionalert-5d1b8.firebaseapp.com",
        databaseURL: "https://covidactionalert-5d1b8-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "covidactionalert-5d1b8",
        storageBucket: "covidactionalert-5d1b8.appspot.com",
        messagingSenderId: "470027153289",
        appId: "1:470027153289:web:e1ca0c94fd0e49c905bb58"
      };
firebase.initializeApp(firebaseConfig);

export default firebase;

